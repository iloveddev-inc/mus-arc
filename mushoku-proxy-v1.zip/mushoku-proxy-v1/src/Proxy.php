<?php

final class Proxy
{
    private const BASE_URL = 'https://mushoku.eu.cc';

    public static function run(): void
    {
        $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $query = $_SERVER['QUERY_STRING'] ?? '';

        // Evita reenviar archivos locales.
        if ($path === '/index.php') {
            $path = '/';
        }

        $url = self::BASE_URL . $path . ($query !== '' ? '?' . $query : '');

        $ch = curl_init($url);

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_HTTPHEADER => [
                'Accept: */*',
                'User-Agent: ' . ($_SERVER['HTTP_USER_AGENT'] ?? 'Mushoku-App/1.0'),
            ],
        ]);

        $body = curl_exec($ch);

        if ($body === false) {
            $error = curl_error($ch);
            curl_close($ch);

            http_response_code(502);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'ok' => false,
                'error' => $error,
            ], JSON_UNESCAPED_UNICODE);
            return;
        }

        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        curl_close($ch);

        http_response_code($status ?: 200);

        if ($contentType) {
            header('Content-Type: ' . $contentType);
        }

        // Devuelve el body recibido sin modificarlo.
        echo $body;
    }
}
