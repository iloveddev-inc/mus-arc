<?php
require __DIR__ . '/src/Proxy.php';

Proxy::run();
