# Mushoku.eu.cc Proxy

Proxy HTTP mínimo.

Cualquier GET recibido se reenvía a:

`https://mushoku.eu.cc`

y el body de la respuesta se devuelve sin modificar.

Ejemplos:

- `/`
- `/catalogo/`
- `/buscar/?q=naruto`
- `/anime/slug/`
- `/ep/slug/E1/`
- `/mal/slug/`
- `/ultimos/`
- `/top/`
- `/az/A/`
- `/horario/`

No usa cache, base de datos, scraper, parser ni almacenamiento de respuestas.
