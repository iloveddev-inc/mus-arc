<?php
require __DIR__ . '/src/Scraper.php';
require __DIR__ . '/src/RateLimit.php';

RateLimit::enforce();

/**
 * /ultimos/
 * Trae los últimos episodios publicados y los animes agregados
 * recientemente al catálogo, tal como los muestra la home de AnimeAV1
 * (bloques `latestEpisodes` y `latestMedia` del hydrate de SvelteKit).
 */

try {
    $html = Scraper::fetchCached(Scraper::BASE_URL . '/', 180); // 3 minutos: esto cambia seguido
    $block = Scraper::extractDataBlock($html);

    // El bloque de contenido real es el segundo objeto {type:"data",data:{featured:...}}
    // (el primero es solo {user:null}), así que localizamos explícitamente
    // el que arranca con "featured:" y contamos llaves desde ahí.
    $pos = strpos($block, 'data:{featured:');
    if ($pos === false) {
        Scraper::errorOut('No se pudo procesar la página de inicio (estructura inesperada)', 502);
    }
    $start = $pos + strlen('data:');
    $depth = 0;
    $len = strlen($block);
    $dataBlock = null;
    for ($i = $start; $i < $len; $i++) {
        $c = $block[$i];
        if ($c === '{') $depth++;
        if ($c === '}') {
            $depth--;
            if ($depth === 0) { $dataBlock = substr($block, $start, $i - $start + 1); break; }
        }
    }
    if ($dataBlock === null) {
        Scraper::errorOut('No se pudo procesar la página de inicio (estructura inesperada)', 502);
    }

    // ---- últimos episodios ----
    $episodiosBlock = Scraper::grabArrayBlock($dataBlock, 'latestEpisodes');
    $episodios = [];
    if ($episodiosBlock) {
        foreach (Scraper::splitObjects($episodiosBlock) as $obj) {
            $mediaObj = Scraper::grabObjectBlock($obj, 'media');
            $slug  = $mediaObj ? Scraper::grabString($mediaObj, 'slug') : null;
            $titulo = $mediaObj ? Scraper::grabString($mediaObj, 'title') : null;
            $numero = Scraper::grabNumber($obj, 'number');
            if (!$slug || $numero === null) continue;

            $episodios[] = [
                'anime'         => $titulo,
                'slug'          => $slug,
                'episodio'      => $numero,
                'publicado'     => Scraper::grabString($obj, 'publishedAt'),
                'comentarios'   => Scraper::grabNumber($obj, 'commentsCount'),
                'url'           => "/ep/{$slug}/E{$numero}/",
            ];
        }
    }

    // ---- animes agregados recientemente ----
    $mediaBlock = Scraper::grabArrayBlock($dataBlock, 'latestMedia');
    $recientes = [];
    if ($mediaBlock) {
        foreach (Scraper::splitObjects($mediaBlock) as $obj) {
            $slug = Scraper::grabString($obj, 'slug');
            if (!$slug) continue;

            $categoryObj = Scraper::grabObjectBlock($obj, 'category');

            // OJO: `category` es el primer objeto anidado y también trae su
            // propio `id`, así que buscamos el `id` del anime DESPUÉS de
            // saltar ese sub-objeto (igual que con malId en mal.php).
            $id = null;
            if ($categoryObj !== null) {
                $catPos = strpos($obj, $categoryObj);
                if ($catPos !== false) {
                    $afterCategory = substr($obj, $catPos + strlen($categoryObj));
                    $id = Scraper::grabNumber($afterCategory, 'id');
                }
            }
            if ($id === null) $id = Scraper::grabNumber($obj, 'id'); // fallback

            $recientes[] = [
                'id'       => $id,
                'titulo'   => Scraper::grabString($obj, 'title'),
                'slug'     => $slug,
                'tipo'     => $categoryObj ? Scraper::grabString($categoryObj, 'name') : null,
                'agregado' => Scraper::grabString($obj, 'createdAt'),
                'poster'   => Scraper::posterUrl($id),
                'url'      => "/anime/{$slug}/",
            ];
        }
    }

    Scraper::jsonOut([
        'ok' => true,
        'ultimos_episodios' => $episodios,
        'animes_recientes'  => $recientes,
    ]);

} catch (Throwable $e) {
    Scraper::errorOut($e->getMessage(), $e->getCode() >= 400 && $e->getCode() < 600 ? $e->getCode() : 500);
}
