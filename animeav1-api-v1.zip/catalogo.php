<?php
require __DIR__ . '/src/Scraper.php';
require __DIR__ . '/src/RateLimit.php';

RateLimit::enforce();

try {
    $page   = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $genre  = $_GET['genre']  ?? null;
    $search = $_GET['search'] ?? null;
    $status = $_GET['status'] ?? null;
    $order  = $_GET['order']  ?? null; // p.ej. "popular"

    $query = ['page' => $page];
    if ($genre)  $query['genre']  = $genre;
    if ($search) $query['search'] = $search;
    if ($status) $query['status'] = $status;
    if ($order)  $query['order']  = $order;

    $url  = Scraper::BASE_URL . '/catalogo?' . http_build_query($query);
    $html = Scraper::fetchCached($url, 600); // 10 minutos
    $block = Scraper::extractDataBlock($html);

    $items = Scraper::parseCatalogoResults($block);
    $paginacion = Scraper::parsePagination($block);

    Scraper::jsonOut(array_merge(['ok' => true], $paginacion, ['resultados' => $items]));

} catch (Throwable $e) {
    Scraper::errorOut($e->getMessage(), $e->getCode() >= 400 && $e->getCode() < 600 ? $e->getCode() : 500);
}
