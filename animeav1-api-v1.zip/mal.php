<?php
require __DIR__ . '/src/Scraper.php';
require __DIR__ . '/src/RateLimit.php';

RateLimit::enforce();

/**
 * /mal/{slug}/
 * Cruza el anime de AnimeAV1 con su ficha completa en MyAnimeList
 * (estudio, staff, ranking, etc.) vía Jikan (api.jikan.moe), que es
 * gratis y no requiere API key. Jikan solo entiende IDs de MAL, así que
 * primero sacamos el malId desde AnimeAV1 y con eso pedimos /anime/{id}.
 * La conexión a Jikan vive en Scraper::jikanFetchCached (ver ahí el fix
 * del 504 por el header Accept-Encoding).
 */

try {
    $slug = preg_replace('/[^a-z0-9\-]/i', '', $_GET['slug'] ?? '');
    if ($slug === '') {
        Scraper::errorOut('Falta el slug del anime', 400);
    }

    // Paso 1: sacar el malId desde AnimeAV1 (ya viene en el bloque `media`)
    $url  = Scraper::BASE_URL . '/media/' . $slug;
    $html = Scraper::fetchCached($url, 1800);
    $block = Scraper::extractDataBlock($html);

    $mediaBlock = null;
    if (preg_match('/(?<![a-zA-Z0-9_])media:\{/', $block, $m, PREG_OFFSET_CAPTURE)) {
        $start = $m[0][1] + strlen($m[0][0]) - 1;
        $depth = 0;
        $len = strlen($block);
        for ($i = $start; $i < $len; $i++) {
            $c = $block[$i];
            if ($c === '{') $depth++;
            if ($c === '}') {
                $depth--;
                if ($depth === 0) { $mediaBlock = substr($block, $start, $i - $start + 1); break; }
            }
        }
    }
    if ($mediaBlock === null) {
        Scraper::errorOut('Anime no encontrado en AnimeAV1', 404);
    }

    $malId = Scraper::grabNumber($mediaBlock, 'malId');
    $titulo = Scraper::grabString($mediaBlock, 'title');

    // OJO: el array `genres` trae su propio `malId` por género (id de
    // categoría de MAL), así que si lo buscamos ingenuamente en todo el
    // bloque, matcheamos el primero de esos en lugar del malId del anime.
    // El malId real del anime viene después del array de `genres`, junto
    // a `slug`/`seasons`, así que recortamos el bloque desde ahí.
    $genresEnd = null;
    $genresArr = Scraper::grabArrayBlock($mediaBlock, 'genres');
    if ($genresArr !== null) {
        $genresPos = strpos($mediaBlock, $genresArr);
        if ($genresPos !== false) $genresEnd = $genresPos + strlen($genresArr);
    }
    if ($genresEnd !== null) {
        $malId = Scraper::grabNumber(substr($mediaBlock, $genresEnd), 'malId');
    }

    if (!$malId) {
        Scraper::errorOut('Este anime no tiene malId vinculado en AnimeAV1, no se puede cruzar con MyAnimeList', 404);
    }

    // Paso 2: pedir la ficha a Jikan (cache 24h: esta info cambia poco).
    // Se usa /anime/{id} simple, NO /anime/{id}/full: el endpoint /full es
    // más pesado (agrega relaciones, temas musicales, streaming links) y
    // es el que más falla intermitentemente en Jikan. El simple trae todo
    // lo que necesitamos (score, rank, studios, trailer, synopsis) y es
    // bastante más estable.
    $jikan = Scraper::jikanFetchCached('https://api.jikan.moe/v4/anime/' . $malId, 86400);
    $d = $jikan['data'] ?? null;
    if ($d === null) {
        Scraper::errorOut('MyAnimeList no devolvió datos para este anime', 502);
    }

    $estudios = array_map(fn($s) => $s['name'], $d['studios'] ?? []);
    $productoras = array_map(fn($s) => $s['name'], $d['producers'] ?? []);
    $generos = array_map(fn($g) => $g['name'], $d['genres'] ?? []);

    Scraper::jsonOut([
        'ok' => true,
        'slug' => $slug,
        'mal_id' => $malId,
        'titulo' => $titulo,
        'titulo_ingles' => $d['title_english'] ?? null,
        'titulo_japones' => $d['title_japanese'] ?? null,
        'sinopsis' => $d['synopsis'] ?? null,
        'tipo' => $d['type'] ?? null,
        'fuente' => $d['source'] ?? null,
        'episodios' => $d['episodes'] ?? null,
        'duracion' => $d['duration'] ?? null,
        'estado' => $d['status'] ?? null,
        'emitido' => $d['aired']['string'] ?? null,
        'temporada' => $d['season'] ?? null,
        'año' => $d['year'] ?? null,
        'puntuacion' => $d['score'] ?? null,
        'ranking' => $d['rank'] ?? null,
        'popularidad' => $d['popularity'] ?? null,
        'miembros' => $d['members'] ?? null,
        'estudios' => $estudios,
        'productoras' => $productoras,
        'generos' => $generos,
        'poster_mal' => $d['images']['jpg']['large_image_url'] ?? null,
        'trailer' => $d['trailer']['url'] ?? null,
        'url_mal' => $d['url'] ?? null,
    ]);

} catch (Throwable $e) {
    Scraper::errorOut($e->getMessage(), $e->getCode() >= 400 && $e->getCode() < 600 ? $e->getCode() : 500);
}
