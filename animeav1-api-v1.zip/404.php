<?php
require __DIR__ . '/src/Scraper.php';
Scraper::errorOut('Ruta no encontrada. Usa /catalogo/, /buscar/?q=, /anime/{slug}/, /ep/{slug}/E{n}/, /mal/{slug}/, /ultimos/, /top/, /az/{letra}/ o /horario/', 404);
