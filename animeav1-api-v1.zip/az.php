<?php
require __DIR__ . '/src/Scraper.php';
require __DIR__ . '/src/RateLimit.php';

RateLimit::enforce();

/**
 * /az/{letra}/
 * Catálogo filtrado por letra inicial, usando el parámetro `letter`
 * real de AnimeAV1 (letter=A, letter=B, ...). Acepta minúscula o
 * mayúscula en la URL, siempre se normaliza a mayúscula al pedirlo.
 */

try {
    $letra = strtoupper(substr(preg_replace('/[^a-zA-Z]/', '', $_GET['letra'] ?? ''), 0, 1));
    if ($letra === '') {
        Scraper::errorOut('Falta la letra a filtrar, p. ej. /az/a/', 400);
    }

    $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $order = $_GET['order'] ?? null; // opcional: /az/a/?order=popular

    $query = ['letter' => $letra, 'page' => $page];
    if ($order) $query['order'] = $order;

    $url  = Scraper::BASE_URL . '/catalogo?' . http_build_query($query);
    $html = Scraper::fetchCached($url, 1800); // 30 minutos: cambia poco
    $block = Scraper::extractDataBlock($html);

    $items = Scraper::parseCatalogoResults($block);
    $paginacion = Scraper::parsePagination($block);

    Scraper::jsonOut(array_merge(['ok' => true, 'letra' => $letra], $paginacion, ['resultados' => $items]));

} catch (Throwable $e) {
    Scraper::errorOut($e->getMessage(), $e->getCode() >= 400 && $e->getCode() < 600 ? $e->getCode() : 500);
}
