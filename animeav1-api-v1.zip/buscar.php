<?php
require __DIR__ . '/src/Scraper.php';
require __DIR__ . '/src/RateLimit.php';

RateLimit::enforce();

try {
    $q = trim($_GET['q'] ?? '');
    if ($q === '') {
        Scraper::errorOut('Falta el parámetro ?q= con el término a buscar', 400);
    }

    $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;

    $query = ['search' => $q, 'page' => $page];
    $url  = Scraper::BASE_URL . '/catalogo?' . http_build_query($query);
    $html = Scraper::fetchCached($url, 300); // 5 minutos, las búsquedas cambian menos que el catálogo general
    $block = Scraper::extractDataBlock($html);

    $resultsBlock = Scraper::grabArrayBlock($block, 'results');
    if ($resultsBlock === null) {
        Scraper::errorOut('No se pudo procesar la búsqueda (estructura inesperada)', 502);
    }

    $items = [];
    foreach (Scraper::splitObjects($resultsBlock) as $obj) {
        $id   = Scraper::grabNumber($obj, 'id') ?? Scraper::grabString($obj, 'id');
        $slug = Scraper::grabString($obj, 'slug');
        if (!$slug) continue;

        $items[] = [
            'id'       => $id,
            'titulo'   => Scraper::grabString($obj, 'title'),
            'sinopsis' => Scraper::grabString($obj, 'synopsis'),
            'slug'     => $slug,
            'poster'   => Scraper::posterUrl($id),
            'url'      => "/anime/{$slug}/",
        ];
    }

    $totalRecords = null;
    if (preg_match('/pagination:\{currentPage:(\d+),recordsPerPage:(\d+),totalPages:(\d+),totalRecords:(\d+)\}/', $block, $m)) {
        $totalRecords = (int)$m[4];
    }

    Scraper::jsonOut([
        'ok' => true,
        'consulta' => $q,
        'pagina_actual' => $page,
        'total_resultados' => $totalRecords,
        'resultados' => $items,
    ]);

} catch (Throwable $e) {
    Scraper::errorOut($e->getMessage(), $e->getCode() >= 400 && $e->getCode() < 600 ? $e->getCode() : 500);
}
