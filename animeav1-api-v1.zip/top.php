<?php
require __DIR__ . '/src/Scraper.php';
require __DIR__ . '/src/RateLimit.php';

RateLimit::enforce();

/**
 * /top/
 * Atajo de /catalogo/?order=popular — los animes más populares de
 * AnimeAV1, sin necesidad de armar el query a mano.
 */

try {
    $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;

    $url  = Scraper::BASE_URL . '/catalogo?' . http_build_query(['order' => 'popular', 'page' => $page]);
    $html = Scraper::fetchCached($url, 900); // 15 minutos: el top cambia poco
    $block = Scraper::extractDataBlock($html);

    $items = Scraper::parseCatalogoResults($block);
    $paginacion = Scraper::parsePagination($block);

    Scraper::jsonOut(array_merge(['ok' => true], $paginacion, ['resultados' => $items]));

} catch (Throwable $e) {
    Scraper::errorOut($e->getMessage(), $e->getCode() >= 400 && $e->getCode() < 600 ? $e->getCode() : 500);
}
