<?php
require __DIR__ . '/src/Scraper.php';
Scraper::jsonOut([
    'ok' => true,
    'nombre' => 'AnimeAV1 API (no oficial)',
    'endpoints' => [
        'GET /catalogo/'                => 'Lista el catálogo. Query opcional: ?page=1&genre=accion&search=&status=',
        'GET /buscar/?q='               => 'Búsqueda dedicada por título. Query opcional: &page=1',
        'GET /anime/{slug}/'            => 'Info del anime + lista de episodios',
        'GET /ep/{slug}/E{numero}/'     => 'Servers de streaming (DUB/SUB) y descargas del episodio',
        'GET /mal/{slug}/'              => 'Ficha completa de MyAnimeList (estudios, ranking, etc.) vía Jikan',
        'GET /ultimos/'                 => 'Últimos episodios publicados y animes agregados recientemente',
        'GET /top/'                     => 'Catálogo ordenado por popularidad',
        'GET /az/{letra}/'              => 'Catálogo filtrado por letra inicial',
        'GET /horario/'                 => 'Animes en emisión activa, agrupados por día según su último episodio',
    ],
    'ejemplo' => [
        '/catalogo/?page=1',
        '/buscar/?q=kimetsu',
        '/anime/kimetsu-no-yaiba/',
        '/ep/kimetsu-no-yaiba/E1/',
        '/mal/kimetsu-no-yaiba/',
        '/ultimos/',
        '/top/',
        '/az/a/',
        '/horario/',
    ],
    'limites' => 'Máximo 30 solicitudes por minuto por IP (código 429 si se excede)',
]);
