<?php
require __DIR__ . '/src/Scraper.php';
require __DIR__ . '/src/RateLimit.php';

RateLimit::enforce();

/**
 * /horario/
 * AnimeAV1 no expone un calendario lunes-domingo con horas fijas de
 * emisión: /horario trae una lista de animes activos junto con la
 * fecha real de publicación de su último episodio (`latestEpisode.
 * createdAt`). Aquí se agrupa esa lista por día de la semana (según
 * esa fecha) para dar una vista tipo "calendario" real, sin inventar
 * horarios que el sitio no provee.
 */

$DIAS = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

try {
    $html = Scraper::fetchCached(Scraper::BASE_URL . '/horario', 900); // 15 minutos
    $block = Scraper::extractDataBlock($html);

    // El bloque real de contenido es el segundo objeto {type:"data",data:{media:...}}
    // (el primero es solo {user:null}), igual que en ultimos.php.
    $pos = strpos($block, 'data:{media:[');
    if ($pos === false) {
        Scraper::errorOut('No se pudo procesar el horario (estructura inesperada)', 502);
    }
    $start = $pos + strlen('data:');
    $depth = 0;
    $len = strlen($block);
    $dataBlock = null;
    for ($i = $start; $i < $len; $i++) {
        $c = $block[$i];
        if ($c === '{') $depth++;
        if ($c === '}') {
            $depth--;
            if ($depth === 0) { $dataBlock = substr($block, $start, $i - $start + 1); break; }
        }
    }
    if ($dataBlock === null) {
        Scraper::errorOut('No se pudo procesar el horario (estructura inesperada)', 502);
    }

    $mediaBlock = Scraper::grabArrayBlock($dataBlock, 'media');
    $porDia = array_fill_keys($GLOBALS['DIAS'], []);

    if ($mediaBlock) {
        foreach (Scraper::splitObjects($mediaBlock) as $obj) {
            $slug = Scraper::grabString($obj, 'slug');
            if (!$slug) continue;

            $categoryObj = Scraper::grabObjectBlock($obj, 'category');
            $id = null;
            if ($categoryObj !== null) {
                $catPos = strpos($obj, $categoryObj);
                if ($catPos !== false) {
                    $id = Scraper::grabNumber(substr($obj, $catPos + strlen($categoryObj)), 'id');
                }
            }
            if ($id === null) $id = Scraper::grabNumber($obj, 'id');

            $epObj = Scraper::grabObjectBlock($obj, 'latestEpisode');
            $numero = $epObj ? Scraper::grabNumber($epObj, 'number') : null;
            $publicado = $epObj ? Scraper::grabString($epObj, 'createdAt') : null;

            $dia = null;
            if ($publicado) {
                $ts = strtotime($publicado);
                if ($ts !== false) $dia = $GLOBALS['DIAS'][(int)date('w', $ts)];
            }
            if ($dia === null) continue; // sin fecha no se puede ubicar en el calendario

            $porDia[$dia][] = [
                'id'              => $id,
                'titulo'          => Scraper::grabString($obj, 'title'),
                'slug'            => $slug,
                'tipo'            => $categoryObj ? Scraper::grabString($categoryObj, 'name') : null,
                'poster'          => Scraper::posterUrl($id),
                'ultimo_episodio' => $numero,
                'publicado'       => $publicado,
                'url'             => "/anime/{$slug}/",
            ];
        }
    }

    Scraper::jsonOut([
        'ok' => true,
        'nota' => 'Agrupado por el día real de publicación del último episodio (AnimeAV1 no expone horarios fijos)',
        'horario' => $porDia,
    ]);

} catch (Throwable $e) {
    Scraper::errorOut($e->getMessage(), $e->getCode() >= 400 && $e->getCode() < 600 ? $e->getCode() : 500);
}
