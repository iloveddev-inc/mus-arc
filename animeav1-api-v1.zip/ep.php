<?php
require __DIR__ . '/src/Scraper.php';
require __DIR__ . '/src/RateLimit.php';

RateLimit::enforce();

/**
 * Extrae { DUB: [{server,url}], SUB: [{server,url}] } a partir del bloque
 * "embeds:{DUB:[...],SUB:[...]}" o "downloads:{DUB:[...],SUB:[...]}"
 */
function extraerServersPorIdioma(string $block, string $key): array
{
    $pos = strpos($block, $key . ':{');
    if ($pos === false) return [];

    $start = $pos + strlen($key . ':');
    $depth = 0;
    $len = strlen($block);
    $groupBlock = null;
    for ($i = $start; $i < $len; $i++) {
        $c = $block[$i];
        if ($c === '{') $depth++;
        if ($c === '}') {
            $depth--;
            if ($depth === 0) { $groupBlock = substr($block, $start, $i - $start + 1); break; }
        }
    }
    if ($groupBlock === null) return [];

    $resultado = [];
    foreach (['DUB', 'SUB'] as $idioma) {
        $arr = Scraper::grabArrayBlock($groupBlock, $idioma);
        if ($arr === null) continue;
        $lista = [];
        foreach (Scraper::splitObjects($arr) as $obj) {
            $server = Scraper::grabString($obj, 'server');
            $url    = Scraper::grabString($obj, 'url');
            if ($server && $url) {
                $lista[] = ['servidor' => $server, 'url' => $url];
            }
        }
        if ($lista) $resultado[$idioma] = $lista;
    }
    return $resultado;
}

try {
    $slug   = preg_replace('/[^a-z0-9\-]/i', '', $_GET['slug'] ?? '');
    $numero = preg_replace('/[^0-9]/', '', $_GET['numero'] ?? '');

    if ($slug === '' || $numero === '') {
        Scraper::errorOut('Faltan parámetros: slug y número de episodio', 400);
    }

    $url  = Scraper::BASE_URL . "/media/{$slug}/{$numero}";
    $html = Scraper::fetchCached($url, 3600); // 1 hora
    $block = Scraper::extractDataBlock($html);

    // Bloque "media:{...}" para título del anime
    $mediaTitulo = null;
    $mediaId = null;
    if (preg_match('/media:\{id:(\d+)[^}]*?title:"((?:[^"\\\\]|\\\\.)*)"/', $block, $m)) {
        $mediaId = (int)$m[1];
        $mediaTitulo = Scraper::unescapeJs($m[2]);
    }

    // Bloque "episode:{...}" para datos propios del episodio
    $episodeBlock = null;
    if (preg_match('/episode:\{/', $block, $m, PREG_OFFSET_CAPTURE)) {
        $start = $m[0][1] + strlen('episode:');
        $depth = 0;
        $len = strlen($block);
        for ($i = $start; $i < $len; $i++) {
            $c = $block[$i];
            if ($c === '{') $depth++;
            if ($c === '}') {
                $depth--;
                if ($depth === 0) { $episodeBlock = substr($block, $start, $i - $start + 1); break; }
            }
        }
    }

    if ($episodeBlock === null) {
        Scraper::errorOut('Episodio no encontrado', 404);
    }

    $embeds    = extraerServersPorIdioma($block, 'embeds');
    $downloads = extraerServersPorIdioma($block, 'downloads');

    if (empty($embeds)) {
        Scraper::errorOut('No se encontraron servidores para este episodio', 502);
    }

    Scraper::jsonOut([
        'ok' => true,
        'anime' => [
            'id'    => $mediaId,
            'titulo'=> $mediaTitulo,
            'slug'  => $slug,
        ],
        'episodio' => (int)$numero,
        'servers' => $embeds,     // reproducir: {"DUB":[{servidor,url}],"SUB":[...]}
        'descargas' => $downloads, // enlaces de descarga por servidor/idioma
    ]);

} catch (Throwable $e) {
    Scraper::errorOut($e->getMessage(), $e->getCode() >= 400 && $e->getCode() < 600 ? $e->getCode() : 500);
}
