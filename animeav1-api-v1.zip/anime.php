<?php
require __DIR__ . '/src/Scraper.php';
require __DIR__ . '/src/RateLimit.php';

RateLimit::enforce();

try {
    $slug = $_GET['slug'] ?? '';
    $slug = preg_replace('/[^a-z0-9\-]/i', '', $slug);
    if ($slug === '') {
        Scraper::errorOut('Falta el slug del anime', 400);
    }

    // La página /media/{slug} trae portada+géneros pero para episodes[]
    // completos y datos ricos usamos el mismo bloque `media` que aparece
    // también en /media/{slug}/1 (fallback) si la ficha general no trae episodes.
    $url  = Scraper::BASE_URL . '/media/' . $slug;
    $html = Scraper::fetchCached($url, 1800); // 30 minutos
    $block = Scraper::extractDataBlock($html);

    $mediaBlock = null;
    if (preg_match('/media:\{/', $block, $m, PREG_OFFSET_CAPTURE)) {
        $start = $m[0][1] + strlen('media:');
        $depth = 0;
        $len = strlen($block);
        for ($i = $start; $i < $len; $i++) {
            $c = $block[$i];
            if ($c === '{') $depth++;
            if ($c === '}') {
                $depth--;
                if ($depth === 0) { $mediaBlock = substr($block, $start, $i - $start + 1); break; }
            }
        }
    }

    if ($mediaBlock === null) {
        Scraper::errorOut('Anime no encontrado o estructura inesperada', 404);
    }

    $id = Scraper::grabNumber($mediaBlock, 'id');

    $genresBlock = Scraper::grabArrayBlock($mediaBlock, 'genres');
    $generos = [];
    if ($genresBlock) {
        foreach (Scraper::splitObjects($genresBlock) as $g) {
            $generos[] = [
                'nombre' => Scraper::grabString($g, 'name'),
                'slug'   => Scraper::grabString($g, 'slug'),
            ];
        }
    }

    $episodesBlock = Scraper::grabArrayBlock($mediaBlock, 'episodes');
    $episodios = [];
    if ($episodesBlock) {
        foreach (Scraper::splitObjects($episodesBlock) as $e) {
            $num = Scraper::grabNumber($e, 'number');
            if ($num === null) continue;
            $episodios[] = [
                'numero' => $num,
                'url'    => "/ep/{$slug}/E{$num}/",
            ];
        }
    }

    $categoryBlock = null;
    if (preg_match('/category:\{[^}]*\}/', $mediaBlock, $m)) {
        $categoryBlock = $m[0];
    }

    // ---- malId: viene DESPUÉS del array `genres`, que también trae su
    // propio malId por género (id de categoría MAL, no del anime) ----
    $malId = null;
    $genresRaw = Scraper::grabArrayBlock($mediaBlock, 'genres');
    if ($genresRaw !== null) {
        $genresPos = strpos($mediaBlock, $genresRaw);
        if ($genresPos !== false) {
            $malId = Scraper::grabNumber(substr($mediaBlock, $genresPos + strlen($genresRaw)), 'malId');
        }
    }

    $respuesta = [
        'ok' => true,
        'id' => $id,
        'titulo' => Scraper::grabString($mediaBlock, 'title'),
        'sinopsis' => Scraper::grabString($mediaBlock, 'synopsis'),
        'slug' => $slug,
        'poster' => Scraper::posterUrl($id),
        'tipo' => $categoryBlock ? Scraper::grabString($categoryBlock, 'name') : null,
        'estado' => Scraper::grabNumber($mediaBlock, 'status'),
        'año_inicio' => Scraper::grabString($mediaBlock, 'startDate'),
        'año_fin' => Scraper::grabString($mediaBlock, 'endDate'),
        'puntuacion' => Scraper::grabNumber($mediaBlock, 'score'),
        'votos' => Scraper::grabNumber($mediaBlock, 'votes'),
        'total_episodios' => Scraper::grabNumber($mediaBlock, 'episodesCount'),
        'generos' => $generos,
        'episodios' => $episodios,
    ];

    // ---- Fusión con MyAnimeList (Jikan) ----
    // Si hay malId vinculado, se intenta enriquecer con MAL: la sinopsis
    // se reemplaza por la de MAL (suele ser más completa/traducida) y se
    // agrega un bloque `mal` con estudio, ranking, trailer, etc. Si Jikan
    // falla (504, rate limit, etc.) la respuesta de AnimeAV1 sigue
    // saliendo completa, solo sin el bloque `mal`.
    $respuesta['mal'] = null;
    if ($malId) {
        try {
            $jikan = Scraper::jikanFetchCached('https://api.jikan.moe/v4/anime/' . $malId, 86400);
            $d = $jikan['data'] ?? null;
            if ($d !== null) {
                if (!empty($d['synopsis'])) {
                    $respuesta['sinopsis'] = $d['synopsis'];
                }
                $respuesta['mal'] = [
                    'ok' => true,
                    'mal_id' => $malId,
                    'titulo' => $d['title'] ?? null,
                    'puntuacion' => $d['score'] ?? null,
                    'ranking' => $d['rank'] ?? null,
                    'estudios' => array_map(fn($s) => $s['name'], $d['studios'] ?? []),
                    'trailer' => $d['trailer']['url'] ?? null,
                    'url_mal' => $d['url'] ?? null,
                ];
            }
        } catch (Throwable $e) {
            // Jikan falló: no rompemos la respuesta principal, solo
            // dejamos constancia del motivo dentro de `mal`.
            $respuesta['mal'] = ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    Scraper::jsonOut($respuesta);

} catch (Throwable $e) {
    Scraper::errorOut($e->getMessage(), $e->getCode() >= 400 && $e->getCode() < 600 ? $e->getCode() : 500);
}
