<?php
/**
 * Scraper.php
 * Utilidades para descargar y extraer el bloque de datos embebido
 * (SvelteKit hydrate: `data: [null, ...]`) que trae AnimeAV1 en cada
 * página, ya que ahí vienen los campos estructurados sin necesitar
 * DOMDocument ni ejecutar JS.
 */

class Scraper
{
    const BASE_URL = 'https://animeav1.com';
    const CDN_URL  = 'https://cdn.animeav1.com';
    const UA       = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

    /**
     * Devuelve el HTML cacheado en disco si sigue vigente (dentro de $ttl
     * segundos), o null si no existe / expiró. Evita golpear AnimeAV1 en
     * cada request repetido y acelera las respuestas.
     */
    public static function fetchCached(string $url, int $ttl): string
    {
        $dir = __DIR__ . '/../cache';
        if (!is_dir($dir)) @mkdir($dir, 0775, true);

        $file = $dir . '/' . md5($url) . '.html';
        if (is_file($file) && (time() - filemtime($file)) < $ttl) {
            $cached = file_get_contents($file);
            if ($cached !== false && $cached !== '') return $cached;
        }

        $html = self::fetch($url);
        @file_put_contents($file, $html);
        return $html;
    }

    /**
     * Descarga el HTML crudo de una URL de animeav1.com
     */
    public static function fetch(string $url): string
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 20,
            CURLOPT_USERAGENT      => self::UA,
            CURLOPT_HTTPHEADER     => [
                'Accept: text/html,application/xhtml+xml',
                'Accept-Language: es-ES,es;q=0.9',
            ],
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $html = curl_exec($ch);
        $err  = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($html === false || $err) {
            throw new RuntimeException("Error al conectar con AnimeAV1: $err");
        }
        if ($code >= 400) {
            throw new RuntimeException("AnimeAV1 respondió HTTP $code", $code);
        }
        return $html;
    }

    /**
     * Extrae el bloque JS embebido `data: [null, ... ]` que SvelteKit
     * inyecta en cada página con los datos ya resueltos server-side.
     * Devuelve el texto crudo del bloque (JS object literal, no JSON válido).
     */
    public static function extractDataBlock(string $html): string
    {
        $start = strpos($html, 'data: [null,');
        if ($start === false) {
            throw new RuntimeException('No se encontró el bloque de datos en la página (¿cambió la estructura del sitio?)');
        }
        // El bloque termina antes de "\n\t\t\t\t\t\t\tform: null," que cierra el objeto padre.
        $end = strpos($html, 'form: null', $start);
        if ($end === false) {
            $end = strpos($html, '</script>', $start);
        }
        return substr($html, $start + strlen('data: ['), $end - ($start + strlen('data: [')));
    }

    /**
     * Extrae un valor string de un objeto-JS tipo  clave:"valor"  o clave:'valor'
     */
    public static function grabString(string $block, string $key): ?string
    {
        if (preg_match('/(?<![a-zA-Z0-9_])' . preg_quote($key, '/') . '\s*:\s*"((?:[^"\\\\]|\\\\.)*)"/u', $block, $m)) {
            return self::unescapeJs($m[1]);
        }
        return null;
    }

    /**
     * Extrae un valor numérico  clave:123  o clave:12.34
     * (?<![a-zA-Z0-9_]) evita que "id" matchee dentro de "categoryId"
     */
    public static function grabNumber(string $block, string $key)
    {
        if (preg_match('/(?<![a-zA-Z0-9_])' . preg_quote($key, '/') . '\s*:\s*(-?\d+(?:\.\d+)?)/', $block, $m)) {
            return strpos($m[1], '.') !== false ? (float)$m[1] : (int)$m[1];
        }
        return null;
    }

    /**
     * Extrae un objeto { } anidado que sigue a "clave:{ ... }" usando
     * conteo de llaves. Útil para sub-objetos como `media:{...}` dentro
     * de un item de lista.
     */
    public static function grabObjectBlock(string $block, string $key): ?string
    {
        if (!preg_match('/(?<![a-zA-Z0-9_])' . preg_quote($key, '/') . ':\{/', $block, $m, PREG_OFFSET_CAPTURE)) {
            return null;
        }
        $start = $m[0][1] + strlen($key) + 1;
        $depth = 0;
        $len = strlen($block);
        for ($i = $start; $i < $len; $i++) {
            $c = $block[$i];
            if ($c === '{') $depth++;
            if ($c === '}') {
                $depth--;
                if ($depth === 0) {
                    return substr($block, $start, $i - $start + 1);
                }
            }
        }
        return null;
    }

    /**
     * Extrae un array JSON-like de objetos { } que sigue a "clave:[ ... ]"
     * usando conteo de llaves para respetar anidamiento. Devuelve el texto
     * crudo del array (incluyendo corchetes) para procesarlo aparte.
     */
    public static function grabArrayBlock(string $block, string $key): ?string
    {
        if (!preg_match('/(?<![a-zA-Z0-9_])' . preg_quote($key, '/') . ':\[/', $block, $m, PREG_OFFSET_CAPTURE)) {
            return null;
        }
        $pos = $m[0][1];
        $start = $pos + strlen($key . ':');
        $depth = 0;
        $len = strlen($block);
        for ($i = $start; $i < $len; $i++) {
            $c = $block[$i];
            if ($c === '[') $depth++;
            if ($c === ']') {
                $depth--;
                if ($depth === 0) {
                    return substr($block, $start, $i - $start + 1);
                }
            }
        }
        return null;
    }

    /**
     * Divide un array de objetos planos "{...},{...},{...}" en sus
     * fragmentos individuales, respetando anidamiento de llaves/corchetes
     * y strings con comas dentro.
     */
    public static function splitObjects(string $arrayBlock): array
    {
        $inner = trim($arrayBlock);
        $inner = substr($inner, 1, -1); // quitar [ ]
        $objects = [];
        $depth = 0;
        $inStr = false;
        $strChar = '';
        $start = 0;
        $len = strlen($inner);
        for ($i = 0; $i < $len; $i++) {
            $c = $inner[$i];
            if ($inStr) {
                if ($c === '\\') { $i++; continue; }
                if ($c === $strChar) $inStr = false;
                continue;
            }
            if ($c === '"' || $c === "'") { $inStr = true; $strChar = $c; continue; }
            if ($c === '{' || $c === '[') $depth++;
            if ($c === '}' || $c === ']') $depth--;
            if ($c === ',' && $depth === 0) {
                $objects[] = substr($inner, $start, $i - $start);
                $start = $i + 1;
            }
        }
        $last = trim(substr($inner, $start));
        if ($last !== '') $objects[] = $last;
        return $objects;
    }

    public static function unescapeJs(string $s): string
    {
        $s = str_replace(['\\n', '\\r', '\\t', '\\"', "\\'", '\\\\'], ["\n", "\r", "\t", '"', "'", '\\'], $s);
        return $s;
    }

    /**
     * URL del poster vía CDN oficial de AnimeAV1, a partir del id numérico.
     */
    public static function posterUrl($id): string
    {
        return self::CDN_URL . '/img/media/poster/' . $id . '.jpg';
    }

    /**
     * Parsea el array `results` que trae /catalogo (y sus variantes con
     * filtros: order, letter, genre, etc.) al formato JSON de salida.
     * Reutilizado por catalogo.php, buscar.php, top.php y az.php.
     */
    public static function parseCatalogoResults(string $block): array
    {
        $resultsBlock = self::grabArrayBlock($block, 'results');
        if ($resultsBlock === null) return [];

        $items = [];
        foreach (self::splitObjects($resultsBlock) as $obj) {
            $id   = self::grabNumber($obj, 'id') ?? self::grabString($obj, 'id');
            $slug = self::grabString($obj, 'slug');
            if (!$slug) continue;

            $items[] = [
                'id'       => $id,
                'titulo'   => self::grabString($obj, 'title'),
                'sinopsis' => self::grabString($obj, 'synopsis'),
                'slug'     => $slug,
                'poster'   => self::posterUrl($id),
                'url'      => "/anime/{$slug}/",
            ];
        }
        return $items;
    }

    /**
     * Extrae currentPage/recordsPerPage/totalPages/totalRecords del
     * bloque de datos de una página de catálogo.
     */
    public static function parsePagination(string $block): array
    {
        if (preg_match('/pagination:\{currentPage:(\d+),recordsPerPage:(\d+),totalPages:(\d+),totalRecords:(\d+)\}/', $block, $m)) {
            return [
                'pagina_actual'    => (int)$m[1],
                'por_pagina'       => (int)$m[2],
                'total_paginas'    => (int)$m[3],
                'total_resultados' => (int)$m[4],
            ];
        }
        return ['pagina_actual' => null, 'por_pagina' => null, 'total_paginas' => null, 'total_resultados' => null];
    }

    /**
     * Pide a Jikan (api.jikan.moe) con caché en disco. IMPORTANTE: no se
     * debe enviar el header `Accept-Encoding` en la petición — es un bug
     * conocido y documentado de Jikan (ver jikan-me/jikan-rest#issues):
     * si el cliente HTTP manda `Accept-Encoding: gzip` (cURL lo agrega
     * solo si se activa CURLOPT_ENCODING), Jikan responde 504 de forma
     * consistente. Sin ese header, responde 200 normal. Por eso aquí NO
     * se activa CURLOPT_ENCODING ni se manda el header a mano.
     *
     * Además, Jikan es conocido por fallos intermitentes (500/504) en el
     * mismo request — el mismo ID que falla ahora puede responder bien
     * unos segundos después (ver jikan-rest#610, #540). Por eso se hace
     * un reintento automático antes de dar el fallo por definitivo.
     */
    public static function jikanFetchCached(string $url, int $ttl, int $intentos = 2): array
    {
        $dir = __DIR__ . '/../cache';
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        $file = $dir . '/jikan_' . md5($url) . '.json';

        if (is_file($file) && (time() - filemtime($file)) < $ttl) {
            $cached = json_decode(file_get_contents($file), true);
            if ($cached !== null) return $cached;
        }

        $ultimoError = null;
        for ($intento = 1; $intento <= $intentos; $intento++) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 15,
                CURLOPT_USERAGENT => self::UA,
                CURLOPT_HTTPHEADER => ['Accept: application/json'],
                // OJO: sin CURLOPT_ENCODING y sin header Accept-Encoding a
                // propósito — ver nota arriba, esto es lo que evita el 504.
            ]);
            $body = curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $err  = curl_error($ch);
            curl_close($ch);

            if ($body !== false && !$err && $code < 400) {
                $data = json_decode($body, true);
                if ($data !== null) {
                    @file_put_contents($file, json_encode($data));
                    return $data;
                }
                $ultimoError = new RuntimeException('Respuesta inválida de Jikan');
            } elseif ($code === 429) {
                // no reintentar en rate limit, solo empeoraría las cosas
                throw new RuntimeException('Jikan (MAL) está limitando las solicitudes en este momento', 429);
            } else {
                $ultimoError = new RuntimeException(
                    $err ? "Error al conectar con Jikan/MAL: $err" : "Jikan respondió HTTP $code",
                    $code >= 400 ? $code : 502
                );
            }

            if ($intento < $intentos) usleep(400000); // 0.4s antes de reintentar
        }

        throw $ultimoError ?? new RuntimeException('Jikan/MyAnimeList no está disponible en este momento', 502);
    }

    public static function jsonOut(array $data, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Access-Control-Allow-Origin: *');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        exit;
    }

    public static function errorOut(string $message, int $status = 500): void
    {
        self::jsonOut(['ok' => false, 'error' => $message], $status);
    }
}
