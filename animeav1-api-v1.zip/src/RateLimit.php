<?php
/**
 * RateLimit.php
 * Límite simple por IP usando archivos en disco (sin base de datos).
 * Objetivo: que un solo cliente no pueda martillar la API (y de rebote
 * a AnimeAV1 o a Jikan) con cientos de requests por segundo.
 */

class RateLimit
{
    // Ventana y máximo de requests dentro de esa ventana, por IP.
    const WINDOW_SECONDS = 60;
    const MAX_REQUESTS   = 30; // 30 requests por minuto por IP

    public static function enforce(): void
    {
        $ip  = $_SERVER['HTTP_CF_CONNECTING_IP']
            ?? $_SERVER['HTTP_X_FORWARDED_FOR']
            ?? $_SERVER['REMOTE_ADDR']
            ?? 'unknown';
        // Si viene una lista (proxy), quedarse con la primera IP real.
        $ip = trim(explode(',', $ip)[0]);

        $dir = __DIR__ . '/../cache/ratelimit';
        if (!is_dir($dir)) @mkdir($dir, 0775, true);

        $file = $dir . '/' . md5($ip) . '.json';
        $now  = time();

        $hits = [];
        if (is_file($file)) {
            $raw = @file_get_contents($file);
            $hits = $raw ? (json_decode($raw, true) ?: []) : [];
        }

        // Descartar marcas fuera de la ventana actual.
        $hits = array_values(array_filter($hits, function ($t) use ($now) {
            return ($now - $t) < self::WINDOW_SECONDS;
        }));

        if (count($hits) >= self::MAX_REQUESTS) {
            $retryAfter = self::WINDOW_SECONDS - ($now - $hits[0]);
            header('Retry-After: ' . max(1, $retryAfter));
            Scraper::errorOut(
                'Demasiadas solicitudes. Intenta de nuevo en unos segundos.',
                429
            );
        }

        $hits[] = $now;
        @file_put_contents($file, json_encode($hits));
    }
}
